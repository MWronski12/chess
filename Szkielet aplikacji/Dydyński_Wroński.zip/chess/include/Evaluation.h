#ifndef EVALUATION_H
#define EVALUATION_H
#include "Board.h"
class Evaluation {
public:
    static int evaluateBoard( Board board ) {
        (void)board;
        return 1;
    }

private:
};

#endif
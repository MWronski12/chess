#!/bin/bash
sudo apt update
sudo apt install libsfml-dev libudev-dev libflac-dev libvorbis-dev libopenal-dev libxcursor-dev libfreetype6-dev libxrandr-dev
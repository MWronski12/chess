#include "Board.h"

class Evaluation {
public:
    static int evaluateBoard( Board board ) {
        (void)board;
        return 1;
    }

private:
};
